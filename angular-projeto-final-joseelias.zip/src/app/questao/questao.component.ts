import { Component, OnInit } from '@angular/core';
import { TodoService } from '../questionario/todo.service';
import { map } from 'rxjs/operators';
import { RouterModule, Routes } from '@angular/router';
import { Usuario, Questionario, QuestaoAberta } from '../dados';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase/app';

@Component({
  selector: 'app-questao',
  templateUrl: './questao.component.html',
  styleUrls: ['./questao.component.css']
})
export class QuestaoComponent implements OnInit {

  private enunciado: string;
  private respostas: string;
  private questionarios: Observable<any>;
  private questionarioAtual: Observable<any>;
  private questao: Observable<any>;
  private usuariokey: string;
  constructor(private service: TodoService, private router:Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(parametros => {
      this.usuariokey = window.localStorage.getItem('uid');
      this.questionarios = this.service.getAllQuestionario(this.usuariokey);
      this.questao = this.service.getAllQuestao(this.usuariokey, window.localStorage.getItem('questionariokey'));
    });
  }

  size(obj) {
    return obj ? Object.keys(obj).length : 0;
  }

  toData(data):number {
    let temp = data.split('/');
    return new Date(parseInt(temp[2]), parseInt(temp[1]) - 1, parseInt(temp[0])).getTime();
  }

  formatDate(timestamp):string{
    let d = new Date(timestamp);
    return (d.getDate() < 10? "0"+d.getDate() : d.getDate())  +"/"+
          (d.getMonth() < 9? "0"+(d.getMonth()+1) : d.getMonth()+1)  +"/"+
          d.getFullYear();
  }

    salvarQuestao() {
    if (this.usuariokey != undefined) {
      let questaoaberta: QuestaoAberta = new QuestaoAberta();
      questaoaberta.enunciado = this.enunciado;
      questaoaberta.respostas = this.respostas;
      this.service.addQuestion(questaoaberta, this.usuariokey, window.localStorage.getItem('questionariokey'));
    }
    else{
      alert("Usuário não definido")
    }
  }

  goto(questionariokey:string):void{
    console.log("usuariokey:" + this.usuariokey +", questionariokey"+ questionariokey );
    this.router.navigate(['/grupo/',this.usuariokey,questionariokey]);
  }

  DeletarQuestao(questaoabertakey: string){
    var resposta = confirm("Tem certeza que deseja remover esta questão?");
    if (resposta == true) {
      console.log("Deletando...");
      console.log("\n Usuario Key: " + this.usuariokey + 
                  "\n Questionario Key: " + window.localStorage.getItem('questionariokey') + 
                  "\n Questao Key: "+ questaoabertakey);
      this.service.DeleteQuestion(this.usuariokey, window.localStorage.getItem('questionariokey'), questaoabertakey)
    }   
  }
}