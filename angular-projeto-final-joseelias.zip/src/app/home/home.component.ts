import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TodoService } from '../questionario/todo.service';
import { map } from 'rxjs/operators';
import { LoginService, User } from '../login/login.service';
import { Subscription } from 'rxjs';
import { ReportService } from '../report.service';
import { MatIconRegistry } from '@angular/material';
import { Usuario, Questionario } from '../dados';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
//import {Timestamp} from 'firebase.firestore';
/* instalar a biblioteca @firebase/util */
import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase/app';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  private user: User;
  private sub: Subscription;

  get authenticated() {
    return this.user !== null;
  }

  myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}

private titulo: string;
  private inicio: string;
  private fim: string;
  private questionarios: Observable<any>;
  private usuariokey: string;
  constructor(private service: TodoService, private router:Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(parametros => {
      this.usuariokey = window.localStorage.getItem('uid');
      this.questionarios = this.service.getAllQuestionario(this.usuariokey);
    });
  }

  size(obj) {
    return obj ? Object.keys(obj).length : 0;
  }

  toData(data):number {
    let temp = data.split('/');
    return new Date(parseInt(temp[2]), parseInt(temp[1]) - 1, parseInt(temp[0])).getTime();
  }

  formatDate(timestamp):string{
    let d = new Date(timestamp);
    return (d.getDate() < 10? "0"+d.getDate() : d.getDate())  +"/"+
          (d.getMonth() < 9? "0"+(d.getMonth()+1) : d.getMonth()+1)  +"/"+
          d.getFullYear();
  }

    DeletarQuestionario(questionariokey: string){
      var resposta = confirm("Tem certeza que deseja remover este questionário?");
 
     if (resposta == true) {
      console.log("Deletando...");
      console.log("\n usuariokey: " + this.usuariokey +"\n questionariokey: "+ questionariokey );
      this.service.DeleteQuiz(this.usuariokey, questionariokey)
     }
  }

  AdicionarQuestao(questionariokey:string): void {
    console.log("Indo para a Tela de Cadastrar Questão \n questionariokey: "+questionariokey);
    window.localStorage.setItem('questionariokey', questionariokey);
    this.router.navigate(['questao']);
  }

  goto(questionariokey:string):void{
    console.log("usuariokey:" + this.usuariokey +", questionariokey"+ questionariokey );
    this.router.navigate(['/grupo/',this.usuariokey,questionariokey]);
  }

  edit(questionario: Questionario, key: string){
    this.service.changeContato(questionario, key);
  }
/*
  todoList;
  constructor(public service: TodoService, private icon: MatIconRegistry,
private report: ReportService, private login: LoginService) { }

  ngOnInit() {
    this.service.getTodoList().pipe(
      map(changes =>
        changes.map(c => ({ key: c.payload.key, ...c.payload.val() }))
      )
    ).subscribe(customers => {
      this.todoList = customers;
    });
        // Registers font awesome among the available sets of icons for mat-icon component
    this.icon.registerFontClassAlias('fontawesome', 'fa');

    // Subscribe to the authState observable to know about login status changes
    this.sub = this.login.authState$.subscribe( user => {

      this.user = user;

    } );
  }
  onSubmit() {
    if (this.service.form.valid) {
      this.service.insertTodo(this.service.form.value);
    }
  }
    ngOnDestroy() {
    this.sub.unsubscribe();
  }
  */
}