import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { HomeComponent } from './home/home.component';
import { QuestionarioComponent } from './questionario/questionario.component';
import { PerfilComponent } from './perfil/perfil.component';
import { UsuarioComponent } from './usuario/usuario.component';
import { QuestaoComponent } from './questao/questao.component';

// Define navigation routes
const routes: Routes = [
  // Global NotFound page using default language content
  { path: 'not-found', component: NotFoundComponent },  
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent }, 
  /*{ path: '**', redirectTo: 'not-found', pathMatch: 'full' },*/
  { path: 'home', component: HomeComponent },
  { path: 'questionario', component: QuestionarioComponent },
  { path: 'perfil', component: PerfilComponent },
  { path: 'login', component: LoginComponent },
  { path: 'questionario/:usuariokey', component: QuestionarioComponent},
  { path: 'usuario', component: UsuarioComponent },
  { path: 'questao', component: QuestaoComponent },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes),
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}