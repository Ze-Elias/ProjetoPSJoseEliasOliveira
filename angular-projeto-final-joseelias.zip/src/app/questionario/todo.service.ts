import { Injectable } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AngularFireDatabase, AngularFireList } from 'angularfire2/database';
import { BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { Usuario, Questionario, Grupo, Questao, QuestaoAberta, Alternativa } from '../dados';

@Injectable()
export class TodoService {

constructor(private firebase: AngularFireDatabase) { }

 insertUsuario(usuario: Usuario): void {
    this.firebase.list('prj/usuario').push(usuario)
      .then((result: any) => {
        console.log(result.key);
      })
      .catch((error: any) => {
        console.error(error);
      });
  }
// Inserir Questionario (INSERT)
  addQuestionario(q: Questionario, key: string): void {
    console.log(q);
    this.firebase.list(`prj/usuario/${key}/questionarios/`).push(q)
      .then((result: any) => {
        console.log(result.key);
      })
      .catch((error: any) => {
        console.error(error);
      });
  }

// Inserir Questão (INSERT)
    addQuestion(q: QuestaoAberta, key: string, questaokey): void {
    console.log(q);
    this.firebase.list(`prj/usuario/${key}/questionarios/${questaokey}/Questoes`).push(q)
      .then((result: any) => {
        console.log(result.key);
      })
      .catch((error: any) => {
        console.error(error);
      });
  }

  //Deletar Questionario (DELETE)
  DeleteQuiz(usuariokey:string, questionariokey) {
    this.firebase.list(`prj/usuario/${usuariokey}/questionarios/`).remove(questionariokey); 
  }

  //Deletar Questao (DELETE)
   DeleteQuestion(usuariokey:string, questionariokey, questaokey) {
    this.firebase.list(`prj/usuario/${usuariokey}/questionarios/${questionariokey}/Questoes`).remove(questaokey); 
  }

// Lel todos os Questionarios de um deterteminado usuario (READ)
  getAllQuestionario(usuariokey:string) {
    return this.firebase.list(`prj/usuario/${usuariokey}/questionarios/`,
      ref => ref.orderByChild('prj/usuario/questionarios/titulo')
    )
      .snapshotChanges() /* pegar as mudanças */
      .pipe(
        /* mapeamento das mudanças */
        map(changes => {
          /* ... são todas as demais propriedades do objeto JSON que está no BD */
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        })
      );
  }

// Ler todas as questoes de um determinado questionario (READ)
    getAllQuestao(usuariokey:string, questionariokey:string) {
    return this.firebase.list(`prj/usuario/${usuariokey}/questionarios/${questionariokey}/Questoes`,
      ref => ref.orderByChild('prj/usuario/questionarios/titulo')
    )
      .snapshotChanges() /* pegar as mudanças */
      .pipe(
        /* mapeamento das mudanças */
        map(changes => {
          /* ... são todas as demais propriedades do objeto JSON que está no BD */
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        })
      );
  }

// Precisei usar isso para fazer funcionar o editar
  private contatoSource = new BehaviorSubject({questionario: null, key: '' });
  currentContato = this.contatoSource.asObservable();
 
  changeContato(questionario: Questionario, key: string) {
    this.contatoSource.next({ questionario: questionario, key: key });
  }

//Editar Questionario (UPDATE)
  editarQuestionario(usuariokey:string, questionario: Questionario, key: string){
      this.firebase.list(`prj/usuario/${usuariokey}/questionarios`).update(key, questionario)
      .catch((error: any) => {
        console.error(error);
      });
  }

//Editar Questao (UPDATE)
  editarQuestao(){

  }
    getAllUsuario() {
    return this.bd.list('prj/usuario',
      ref => ref.orderByChild('usuario')
    )
      .snapshotChanges() /* pegar as mudanças */
      .pipe(
        /* mapeamento das mudanças */
        map(changes => {
          /* ... são todas as demais propriedades do objeto JSON que está no BD */
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        })
      );
  }
  
  getAllGrupo(usuariokey:string, questionariokey:string) {
    return this.firebase.list(`prj/usuario/${usuariokey}/questionarios/${questionariokey}/grupos`,
      ref => ref.orderByChild('prj/usuario/questionarios/grupos/titulo')
    )
      .snapshotChanges() /* pegar as mudanças */
      .pipe(
        /* mapeamento das mudanças */
        map(changes => {
          /* ... são todas as demais propriedades do objeto JSON que está no BD */
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        })
      );
  }


  todoList: AngularFireList<any>;
  addButton: string = 'Adicionar';

  form: FormGroup = new FormGroup({
    key: new FormControl(''),
    title: new FormControl('', Validators.required),
    description: new FormControl('', Validators.required)
  });

  getTodoList() {
    this.todoList = this.firebase.list('todolist');
    return this.todoList.snapshotChanges();
  }
  
  insertTodo(todo) {
    if (todo.key == '') {
      this.todoList.push(todo);
    } else {
      this.todoList.update(todo.key, {
        title: todo.title,
        description: todo.description,
      });
    }
    this.resetForm();
  }
  
  editTodoList(todo: any) {
    todo
    this.form.patchValue(todo);
    this.addButton = 'Atualizar';
  }

  deleteTodoList($key: string) {
    this.todoList.remove($key);
  }
  
  resetForm() {
    this.addButton = 'Adicionar';
    this.form.reset();
  }
}