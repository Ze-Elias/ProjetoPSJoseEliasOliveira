import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { TodoService } from '../questionario/todo.service';
import { Usuario, Questionario } from '../dados';
import { ServicoService } from '../servico.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent implements OnInit {
  
  private usuarioNome: string;
  private usuarios: Observable<any>;
  constructor(private servico: TodoService, private router:Router) { }

  ngOnInit() {
    this.usuarios = this.servico.getAllUsuario();
    console.log(this.usuarios);
  }

  salvarUsuario() {
    if (this.usuarioNome != null && this.usuarioNome.trim() != '') {
      let usuario: Usuario = new Usuario();
      usuario.usuario = this.usuarioNome.trim();
      this.servico.insertUsuario(usuario);
    }
  }

  size(obj) {
    return obj ? Object.keys(obj).length : 0;
  }

  goto(usuariokey:string):void{
    this.router.navigate(['/questao/',usuariokey]);
  }
}