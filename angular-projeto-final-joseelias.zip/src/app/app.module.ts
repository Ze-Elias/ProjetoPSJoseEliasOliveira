import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { MatCardModule} from '@angular/material/card';
import { AngularFireDatabaseModule } from '@angular/fire/database';

import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import {
  MatFormFieldModule,
  MatInputModule,
  MatIconModule,
  MatButtonModule,
  MatProgressBarModule,
  MatDividerModule,
  MatListModule

} from '@angular/material';

import { AppComponent } from './app.component';
import { ReportService } from './report.service';
import { LoginComponent } from './login/login.component';
import { LoginService, config } from './login/login.service';
import { NotFoundComponent } from './not-found/not-found.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './home/home.component';
import { PerfilComponent } from './perfil/perfil.component';
import { QuestionarioComponent } from './questionario/questionario.component';

import { TodoService } from './questionario/todo.service';
import { NavbarComponent } from './navbar/navbar.component';
import { UsuarioComponent } from './usuario/usuario.component';
import { QuestaoComponent } from './questao/questao.component';
import { ServicoService } from './servico.service';
import { RodapeComponent } from './rodape/rodape.component';

var firebaseConfig = {
    apiKey: "AIzaSyCtN7wUo9kT3DXtx14lnIT375Ge9Wbe4xM",
    authDomain: "projetofinal-progscripts-93d36.firebaseapp.com",
    databaseURL: "https://projetofinal-progscripts-93d36.firebaseio.com",
    projectId: "projetofinal-progscripts-93d36",
    storageBucket: "projetofinal-progscripts-93d36.appspot.com",
    messagingSenderId: "156113557870",
    appId: "1:156113557870:web:950903c2306f502c"
  };
@NgModule({
  imports:      [   
    BrowserModule, 
    BrowserAnimationsModule, 
    ReactiveFormsModule,

    FlexLayoutModule,
    RouterModule, 

    FormsModule,

    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    MatProgressBarModule,
    MatDividerModule,
    MatListModule,
  
    AngularFireModule.initializeApp(config),
    AngularFireAuthModule,

    AppRoutingModule,
    
    MatCardModule,
    AngularFireDatabaseModule
  ],
  
  declarations: [ 
    AppComponent, 
    LoginComponent, 
    NotFoundComponent, HomeComponent, PerfilComponent, QuestionarioComponent, NavbarComponent, UsuarioComponent, QuestaoComponent, RodapeComponent
  ],

  providers: [
    LoginService,
    ReportService,
    TodoService,
    ServicoService
  ],
  
  bootstrap: [ AppComponent ]
})
export class AppModule { }
