import { Injectable } from '@angular/core';
import { AngularFireDatabase } from '@angular/fire/database';
import { BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { Usuario, Questionario, Grupo, Questao, QuestaoAberta, Alternativa } from './dados';

@Injectable()
export class ServicoService {
  constructor(private bd: AngularFireDatabase) { }

  insertUsuario(usuario: Usuario): void {
    this.bd.list('prj/usuario').push(usuario)
      .then((result: any) => {
        console.log(result.key);
      })
      .catch((error: any) => {
        console.error(error);
      });
  }

  addQuestionario(q: Questionario, key: string): void {
    console.log( q);
    this.bd.list(`prj/usuario/${key}/questionarios/`).push(q)
      .then((result: any) => {
        console.log(result.key);
      })
      .catch((error: any) => {
        console.error(error);
      });
  }

  getAllUsuario() {
    return this.bd.list('prj/usuario',
      ref => ref.orderByChild('usuario')
    )
      .snapshotChanges() /* pegar as mudanças */
      .pipe(
        /* mapeamento das mudanças */
        map(changes => {
          /* ... são todas as demais propriedades do objeto JSON que está no BD */
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        })
      );
  }

  getAllQuestionario(usuariokey:string) {
    return this.bd.list(`prj/usuario/${usuariokey}/questionarios/`,
      ref => ref.orderByChild('titulo')
    )
      .snapshotChanges() /* pegar as mudanças */
      .pipe(
        /* mapeamento das mudanças */
        map(changes => {
          /* ... são todas as demais propriedades do objeto JSON que está no BD */
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        })
      );
  }


  getAllGrupo(usuariokey:string, questionariokey:string) {
    return this.bd.list(`prj/usuario/${usuariokey}/questionarios/${questionariokey}/grupos`,
      ref => ref.orderByChild('titulo')
    )
      .snapshotChanges() /* pegar as mudanças */
      .pipe(
        /* mapeamento das mudanças */
        map(changes => {
          /* ... são todas as demais propriedades do objeto JSON que está no BD */
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        })
      );
  }


}