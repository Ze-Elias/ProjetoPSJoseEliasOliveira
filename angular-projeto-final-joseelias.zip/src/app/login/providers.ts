export let $authProviders = [

  { name: "google", icon: "fab:fa-google", color: "#EA4335", contrast: "#FFFFFF" },
  { name: "facebook", icon: "fab:fa-facebook", color: "#3B5998", contrast: "#FFFFFF" }
]
